// pages/page2/page2.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    activeKey: 0,
    allProductList: [],
    showProductList: [],
    blackList: [],
    show: false,
    allKindList: ['卸妆', '洁面', '化妆水', '乳液', '面霜', '美容液', '防晒霜', 'ME'],
    nowSelectData: {},
    blackButton: false
  },

  getShowProductList() {
    const nowKind = this.data.allKindList[this.data.activeKey]
    const showList = []
    this.data.allProductList.forEach(item => {
      if (item.kind === nowKind) showList.push(item)
    })
    this.setData({
      showProductList: showList
    })
  },

  addBlack() {
    const that = this
    const userid = wx.getStorageSync('userid')
    wx.request({
      url: 'http://localhost:3000/black/add',
      method: "POST",
      data: {
        userid: userid,
        productid: this.data.nowSelectData.id
      },
      success(res) {
        // const userid = wx.getStorageSync('userid')
        wx.request({
          url: 'http://localhost:3000/black/allData',
          method: "POST",
          data: {
            userid: userid
          },
          success(res) {
            const { data } = res
            that.setData({
              show: false,
              blackList: data.body
            })
          }
        })
        // const { data } = res
        // console.log(data)
      }
    })
  },

  delBlack() {
    const that = this
    const id = this.data.nowSelectData.id
    let blackid = ''
    this.data.blackList.forEach(item => {
      if(item.productid == id) blackid = item.id
    })
    wx.request({
      url: 'http://localhost:3000/black/del',
      method: "POST",
      data: {
        id: blackid
      },
      success(res) {
        const userid = wx.getStorageSync('userid')
        wx.request({
          url: 'http://localhost:3000/black/allData',
          method: "POST",
          data: {
            userid: userid
          },
          success(res) {
            const { data } = res
            that.setData({
              show: false,
              blackList: data.body
            })
          }
        })
      }
    })
  },

  getDetail(e) {
    const id = e.target.dataset.info.id
    let button = false
    this.data.blackList.forEach(item => {
      if(item.productid == id) button = true
    })
    this.setData({
      show: true,
      blackButton: button,
      nowSelectData: e.target.dataset.info
    });
  },

  onClose() {
    this.setData({ show: false });
  },

  onChange(event) {
    this.setData({
      activeKey: event.detail,
      showProductList: []
    })
    this.getShowProductList()
    // console.log(event.detail)
    // console.log(this.data.allProductList)
  },

  inBlack() {
    // blackList
    return true
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    const that = this
    wx.request({
      url: 'http://localhost:3000/product/allData',
      method: "POST",
      success(res) {
        const { data } = res
        that.setData({
          allProductList: data.body
        })
        const userid = wx.getStorageSync('userid')
        wx.request({
          url: 'http://localhost:3000/black/allData',
          method: "POST",
          data: {
            userid: userid
          },
          success(res) {
            const { data } = res
            that.setData({
              blackList: data.body
            })
            that.getShowProductList()
          }
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})