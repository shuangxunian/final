// pages/page1/page1.js
import Notify from '@vant/weapp/notify/notify';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    show: false,
    detailShow: false,
    nowSelectData: {},
    currentDate: new Date().getTime(),
    maxDate: new Date().getTime(),
    userBirthday: '请选择生日',
    formatter(type, value) {
      if (type === 'year') {
        return `${value}年`;
      }
      if (type === 'month') {
        return `${value}月`;
      }
      return value;
    },
    userid: '',
    userName: '',
    userPwd: '',
    active: 0,
    userage: 0,
    // 0首页，1登录，2注册
    nowQuestionId: 0,
    nowSelectIndex: -1,
    allSelectList: [],
    isOil: 0,
    isAllergy: 0,
    isPigmentation: 0,
    isWrinkle: 0,
    showProductNameList: [],
    showProductKindList: [],
    fileList: [],
    showProductList: [
      {
        id: 0,
        productName: '产品1',
        kind: '面霜'
      },
      {
        id: 2,
        productName: '产品2',
        kind: '面霜'
      },
    ],
    questionList: [
      {
        question: "一般情况下，你的肌肤到了中午2、3点左右，会出现下面哪种情况？（如果化妆了，则指在不补妆的情况下）",
        ansList: [
          "干燥起皮屑有种紧绷感，不舒服",
          "看起来还好，和早上起来变化不是太大",
          "T区（前额和鼻子区域）比较油，其他地方还好",
          "不仅仅是T区（前额和鼻子区域）比较油，其他地方看起来也亮亮的，整个面部显得比较油腻、暗沉"
        ],
      },
      {
        question: "洗完脸后不涂抹乳液或面霜，皮肤多久会觉得干燥紧绷？",
        ansList: [
          "皮肤擦干后迅速会觉得干燥紧绷",
          "约半个小时后皮肤才会觉得干燥",
          "皮肤不会觉得干燥",
          "皮肤不觉得干燥，且还会发现有明显的出油情况"
        ],
      },
      {
        question: "你脸上有阻塞的毛孔吗（包括“黑头”和“白头”）",
        ansList: [
          "从来没有",
          "很少有",
          "有时有",
          "总是出现"
        ],
      },
      {
        question: "T区（前额和鼻子一带）出油吗",
        ansList: [
          "从没有油光",
          "有时会有出油现象",
          "经常有出油现象",
          "总是油油的"
        ],
      },
      {
        question: "脸上会出现红色的脓包、痘痘吗",
        ansList: [
          "从不",
          "很少",
          "至少一个月出现一次",
          "至少每周出现一次"
        ],
      },
      {
        question: "使用护肤产品（包括洁面、化妆水、乳液、面膜等）的时候会引发潮红、痒或是刺痛吗？",
        ansList: [
          "从不",
          "很少",
          "经常 ",
          "总是如此"
        ],
      },
      {
        question: "平时皮肤有没有经常出现发红的情况，程度如何？",
        ansList: [
          "没有出现红过皮肤发红",
          "皮肤偶尔会发红，但没注意过是什么原因",
          "皮肤比较容易发红，遇冷遇热，吃辛辣后",
          "皮肤特别容易发红，比如敷面膜后，化妆品后，洗完脸，包括忽冷忽热"
        ],
      },
      {
        question: "在换季或温差较大环境切换时，您的肌肤是否会感觉不适？",
        ansList: [
          "从不",
          "有时",
          "经常",
          "总是这样，每次换季时肌肤都会出现不适感"
        ],
      },
      {
        question: "在经历了适度的运动后，或在压力下，或受到强烈的情感刺激，比如生气的情况下，您的脸部或颈部会经常变红？",
        ansList: [
          "从来没有",
          "有时会",
          "很频繁",
          "总会有"
        ],
      },
      {
        question: "您曾经被诊断过有湿疹或者接触性皮炎吗（指皮肤接触了外界物质而引起瘙痒、肿胀等情况）?",
        ansList: [
          "从来没有",
          "好像有，我不太确定",
          "是的",
          "是的，并且是严重病例"
        ],
      },
      {
        question: "长过痘痘的部位会留下深棕色/黑色的印记吗?",
        ansList: [
          "从不",
          "有时会",
          "经常会",
          "总是这样"
        ],
      },
      {
        question: "日晒之后斑点会加深吗？",
        ansList: [
          "我没有深色斑点",
          "无法确定",
          "色斑会加深",
          "原有色斑会加深，且会出现新的斑点"
        ],
      },
      {
        question: "脸部、前胸、后背或手臂是否有或者曾经有小的棕色斑点（雀斑或黄褐斑）吗？",
        ansList: [
          "没有",
          "有一些（1-5个）",
          "有很多（6-15个）",
          "非常多（16个以上）"
        ],
      },
      {
        question: "几个月没有暴晒当你第一次被暴晒时，皮肤感觉：",
        ansList: [
          "有灼热感，但没有晒黑",
          "有灼热感，且皮肤变黑了",
          "无灼热感，但是皮肤直接变黑了",
          "我的肤色已经很深了，我也分不清这样是否会变得更深"
        ],
      },
      {
        question: "你现在脸上有皱纹吗？",
        ansList: [
          "没有，即使是在做微笑、皱眉、抬眉毛这些表情的时候也没有 ",
          "只有当我微笑、皱眉、抬眉时才有",
          "是的，做表情时有，不运动到的部位也有少量的",
          "即使面无表情，也有明显的皱纹"
        ],
      },
      {
        question: "根据你居住的地区，你所受到的日照属于什么程度呢？",
        ansList: [
          "很少量；我住的地区以阴天为主",
          "有一些；我既在鲜有日照的地方生活过，也在日照比较多的地方生活过",
          "中度的；我居住的地方日照程度中等",
          "很多；我住在热带、南方或是日照时间很长的地方"
        ],
      },
      {
        question: "和同龄人相比，你觉得自己符合下面哪种情况？",
        ansList: [
          "比同龄人年轻1-5岁",
          "和大部分同龄人一样",
          "比同龄人老1-5岁",
          "老5岁以上"
        ],
      },
      {
        question: "你是一个注重防晒的人吗？",
        ansList: [
          "很注重防晒，每天都用防晒霜，出门时还经常使用防晒衣和防晒伞等防晒设备",
          "较为注重防晒，防晒霜或者防晒伞只用一种",
          "不太注重防晒，想起来就用，想不起来就不用了",
          "从来不用防晒霜和防晒设备"
        ],
      },
      {
        question: "在您的生活中，您共抽过多少烟？（或者您曾经接触过吸烟者）",
        ansList: [
          "没有",
          "几包",
          "我不吸烟，但我生活和工作的周围有经常吸烟的人",
          "我每天都吸烟"
        ],
      },
      {
        question: "您在饮食中常常吃水果蔬菜吗？",
        ansList: [
          "每顿都吃",
          "一天一顿",
          "时常",
          "从不"
        ],
      },
    ]
  },

  onChange(event) {
    // wx.switchTab({
    //   url: '/pages/page2/page2',
    // })
    // this.setData({ active: event.detail });
  },

  routerClick(e) {
    if (e.target.dataset.info === "1") {
      wx.navigateTo({
        url: '/pages/page2/page2',
      })
    }
  },

  selectClick(e) {
    this.setData({
      nowSelectIndex: e.target.dataset.info
    })
  },

  begin() {
    this.setData({
      userName:  wx.getStorageSync('username'),
      userid:  wx.getStorageSync('userid')
    })
    if(this.data.userName === '') {
      this.setData({
        nowQuestionId: 1
      })
    } else {
      this.setData({
        nowQuestionId: 3
      })
    }
  },

  showDatePopup() {
    this.setData({
      show: true
    })
  },

  onConfirm(event) {
    const date = new Date(event.detail);
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    this.setData({
      show: false,
      userBirthday: `${year}-${month}-${day}`
    });
  },

  login() {
    const that = this
    if(this.data.userName === '') {
      Notify({ type: 'warning', message: '请输入用户名' });
    } else if (this.data.userPwd === '') {
      Notify({ type: 'warning', message: '请输入密码' });
    } else {
      wx.request({
        url: 'http://localhost:3000/user/login',
        method: "POST",
        data: {
          id: this.data.userName,
          password: this.data.userPwd,
        },
        success(res) {
          const { data } = res
          if (data.code === 5) {
            Notify({ type: 'warning', message: '账号或密码有误，请查证后再登录！' });
          } else {
            wx.setStorage({
              key: 'username',
              data: data.body.username
            })
            wx.setStorage({
              key: 'userid',
              data: data.body.id
            })
            wx.setStorage({
              key: 'id',
              data: data.body.id
            })
            that.setData({
              nowQuestionId: 3
            })
          }
        }
      })
    }
  },

  newUser() {
    const that = this
    if(this.data.userid === '') {
      return Notify({ type: 'warning', message: '请输入手机号' });
    }
    if(this.data.userName === '') {
      return Notify({ type: 'warning', message: '请输入姓名' });
    }
    if(this.data.userPwd === '') {
      return Notify({ type: 'warning', message: '请输入密码' });
    }
    if(this.data.userBirthday === '请选择生日') {
      return Notify({ type: 'warning', message: '请输入生日' });
    }
    wx.request({
      url: 'http://localhost:3000/user/add',
      method: "POST",
      data: {
        id: this.data.userid,
        username: this.data.userName,
        password: this.data.userPwd,
        birthDay: this.data.userBirthday,
      },
      success(res) {
        const { data } = res
        if (data.code === 4) {
          Notify({ type: 'warning', message: '此账号已注册，请直接登陆！' });
        } else {
          wx.setStorage({
            key: 'username',
            data: data.body.username
          })
          wx.setStorage({
            key: 'userid',
            data: data.body.id
          })
          wx.setStorage({
            key: 'birthDay',
            data: data.body.birthDay
          })
          that.setData({
            nowQuestionId: 3
          })
        }
      }
    })
    // this.setData({
    //   nowQuestionId: 3
    // })
  },

  toNewUser() {
    this.setData({
      nowQuestionId: 2
    })
  },

  next() {
    if (this.data.nowSelectIndex === -1 && this.data.nowQuestionId !== 23) {
      Notify({ type: 'warning', message: '请作答！' });
      return
    }
    this.data.allSelectList[this.data.nowQuestionId - 3] = this.data.nowSelectIndex
    // 干油
    if (this.data.nowQuestionId === 6) {
      // >6 油
      let score = 0
      for (let i = 0; i < 4; i++) {
        score += this.data.allSelectList[i]
      }
      wx.setStorage({
        key: 'isOil',
        data: score
      })
      this.setData({
        isOil: score
      })
    }
    // 是否容易过敏
    else if (this.data.nowQuestionId === 12) {
      // >6 容易过敏
      let score = 0
      for (let i = 4; i < 10; i++) {
        score += this.data.allSelectList[i]
      }
      wx.setStorage({
        key: 'isAllergy',
        data: score
      })
      this.setData({
        isAllergy: score
      })
    }
    // 是否是色素沉着性皮肤
    else if (this.data.nowQuestionId === 16) {
      // >6 是色素沉着性皮肤
      let score = 0
      for (let i = 10; i < 14; i++) {
        score += this.data.allSelectList[i]
      }
      wx.setStorage({
        key: 'isPigmentation',
        data: score
      })
      this.setData({
        isPigmentation: score
      })
    }
    // 皱纹性皮肤还是紧致性皮肤
    else if (this.data.nowQuestionId === 22) {
      // >8 皱纹性皮肤
      let score = 0
      for (let i = 14; i < 20; i++) {
        score += this.data.allSelectList[i]
      }
      wx.setStorage({
        key: 'isWrinkle',
        data: score
      })
      this.setData({
        isWrinkle: score
      })
    }
    // else if (this.data.nowQuestionId === 23) {

    // }
    this.setData({
      nowSelectIndex: -1,
      nowQuestionId: this.data.nowQuestionId+1
    })
  },

  getDetail(e) {
    console.log(e.target)
    this.setData({
      detailShow: true,
      nowSelectData: e.target.dataset.info
    });
  },

  last() {
    this.setData({
      nowQuestionId: this.data.nowQuestionId-1,
      nowSelectIndex: this.data.allSelectList[this.data.nowQuestionId - 4]
    })
  },

  afterRead(event) {
    const that = this
    const { file } = event.detail
    wx.request({
      url: 'http://localhost:3000/user/getPostObjectParams',
      method: "POST",
      data: {},
      header: {},
      success(res) {
        wx.uploadFile({
          url: 'https://sxntest.oss-cn-beijing.aliyuncs.com',
          filePath: file.url,
          name: 'file',
          formData: {
            key: file.url.substring(7),
            policy: res.data.policy,
            OSSAccessKeyId: res.data.OSSAccessKeyId,
            signature: res.data.signature
          },
          success(res) {
            wx.request({
              url: 'https://api-cn.faceplusplus.com/facepp/v3/detect',
              method: "POST",
              data: {
                'api_key': 'icVyU8WUGTCkIFngWhfRcQDl8BCIyCKM',
                'api_secret': 'K4mdSop62QV21ZHEC23mT8fjYOENz8jU',
                'image_url': 'https://sxntest.oss-cn-beijing.aliyuncs.com/'+file.url.substring(7),
                'return_attributes': 'age'
              },
              header: {
                'content-type': 'application/x-www-form-urlencoded',
              },
              success(res) {
                that.setData({
                  userage: res.data.faces[0].attributes.age.value,
                  nowQuestionId: that.data.nowQuestionId+1
                })
                wx.request({
                  url: 'http://localhost:3000/product/allData',
                  method: "POST",
                  success(res) {
                    const { data } = res
                    const list = []
                    const isOilText = that.data.isOil > 6 ? "油皮" : "干皮"
                    const isAllergyText = that.data.isAllergy > 6 ? "易致敏" : "不易致敏" 
                    const isPigmentationText = that.data.isPigmentation > 6 ? "能" : "不能"
                    const isWrinkleText = that.data.isWrinkle > 8 ? "皱纹皮肤" : "紧致皮肤"
                    const nowAge = that.data.userage > 65 ? "老年" : "青年"
                    data.body.forEach(item => {
                      if (
                        (item.isOil === isOilText || item.isOil === '全部') &&
                        (item.isAllergy === isAllergyText) &&
                        (item.isPigmentation === isPigmentationText) &&
                        (item.isWrinkle === isWrinkleText || item.isWrinkle === '全部') &&
                        (item.isAge === nowAge || item.isAge === '全部')
                      ) {
                        list.push(item)
                      }
                    })
                    const userid = wx.getStorageSync('userid')
                    wx.request({
                      url: 'http://localhost:3000/black/allData',
                      data: {
                        userid: userid
                      },
                      method: "POST",
                      success(res) {
                        const blackList = []
                        const newList = []
                        res.data.body.forEach(item => {
                          blackList.push(item.productid)
                        })
                        list.forEach(item => {
                          if(!blackList.includes(item.id)) newList.push(item)
                        })
                        that.setData({
                          showProductList: newList
                        })
                      }
                    })
                  }
                })
              }
            })
          },
        });
      },
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    // console.log(this.data.isOil)
    const that = this
    wx.getStorage({
      key: 'userName',
      success (res) {
        that.data.userName = res.data
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})