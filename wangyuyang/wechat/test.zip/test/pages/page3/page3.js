// pages/page3/page3.js
import Notify from '@vant/weapp/notify/notify';

Page({

  /**
   * 页面的初始数据
   */
  data: {
    userid: '',
    username: '',
    userBirthday: '',
    pwdShow: false,
    oldPwd: '',
    newPwd: '',
  },

  showPwdPopup() {
    this.setData({
      pwdShow: true
    })
  },

  onClose() {
    this.setData({
      pwdShow: false,
      oldPwd: '',
      newPwd: ''
    })
  },

  fixPwd() {
    const that = this
    console.log(this.data.oldPwd)
    if(this.data.oldPwd === '') {
      return Notify({ type: 'warning', message: '请输入旧密码' });
    }
    if(this.data.newPwd === '') {
      return Notify({ type: 'warning', message: '请输入新密码' });
    }
    
    wx.request({
      url: 'http://localhost:3000/user/fixPassword',
      method: "POST",
      data: {
        id: wx.getStorageSync('userid'),
        oldPwd: this.data.oldPwd,
        newPwd: this.data.newPwd,
      },
      success(res) {
        that.data.pwdShow = false
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {
    const that = this
    this.setData({
      username: wx.getStorageSync('username'),
      userid:  wx.getStorageSync('userid')
    })
    wx.request({
      url: 'http://localhost:3000/user/info',
      method: "POST",
      data: {
        id: this.data.userid,
      },
      success(res) {
        const { data } = res
        console.log(data)
        that.setData({
          userBirthday: data.body.birthDay
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})