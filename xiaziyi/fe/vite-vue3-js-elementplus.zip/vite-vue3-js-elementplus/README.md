# 快速启动模板

## 技术栈
vue3 + js + elementPlus + axios + vite + pinia

## 启动
npm i
npm run dev
