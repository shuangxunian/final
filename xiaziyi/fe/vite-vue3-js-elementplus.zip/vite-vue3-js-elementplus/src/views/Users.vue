<script setup>
</script>

<template>
  <div>
    user
  </div>
</template>

<style lang="less" scoped>
</style>
