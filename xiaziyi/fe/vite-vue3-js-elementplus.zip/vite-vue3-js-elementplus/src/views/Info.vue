<script setup>
</script>

<template>
  <div>
    info
  </div>
</template>

<style lang="less" scoped>
</style>
