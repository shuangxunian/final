<script setup>
</script>

<template>
  <div id="app">
    <RouterView />
  </div>
</template>

<style scoped>
</style>
